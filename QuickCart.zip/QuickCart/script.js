/* ============================================================
   QuickCart Premium — Professional JS Engine v3.0
   ✦ Stacked/Nested Popups  ✦ Dual Theme  ✦ 3D Product Tilt
   ✦ Fast 3D Loader  ✦ Category Filtering  ✦ WhatsApp Checkout
   ============================================================ */

const products = [
  { id: 1, name: "Perfumes", category: "Fragrance", price: 25, image: "https://i.pinimg.com/736x/9c/b2/5b/9cb25b1f0ed06b93ddf9689dd39ca0cf.jpg", stars: 5 },
  { id: 2, name: "Polo T-Shirt", category: "Fashion", price: 30, image: "https://tse3.mm.bing.net/th/id/OIP.RLGEOTBNCsd7_HUxGzPjjQHaIr?rs=1&pid=ImgDetMain&o=7&rm=3", stars: 4 },
  { id: 3, name: "Formal Shirt", category: "Fashion", price: 20, image: "https://tse3.mm.bing.net/th/id/OIP.uGYkmMlMKarOtbOvRQko_wHaE4?rs=1&pid=ImgDetMain&o=7&rm=3", stars: 5 },
  { id: 4, name: "Sports Wear", category: "Fashion", price: 25, image: "https://th.bing.com/th/id/OIP.h-rpfiQiN9vLrJzKEfwBHwHaE7?w=298&h=199&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3", stars: 4 },
  { id: 5, name: "Sneakers", category: "Footwear", price: 15, image: "https://onedegree.com.pk/cdn/shop/files/001_0003_009593984-749-42_up_jpg_1.jpg?v=1773400763&width=640", stars: 5 },
  { id: 6, name: "Toys", category: "Kids", price: 5, image: "https://www.telegraph.co.uk/content/dam/recommended/2024/09/25/TELEMMGLPICT000395471929_17272789739160_trans_NvBQzQNjv4BqqVzuuqpFlyLIwiB6NTmJwfSVWeZ_vEN7c6bHu2jJnT8.jpeg?imwidth=640", stars: 4 },
  { id: 7, name: "Tablets", category: "Electronics", price: 200, image: "https://i5.walmartimages.com/seo/Lenovo-Tab-M10-Plus-2022-10-FHD-Long-Battery-Life-Tablet-128GB-Android-Storm-Grey_6d20d86e-e339-4dea-a97d-788dbf71f08c.50da7e377a5410315db7b2430fc13a86.png", stars: 5 },
  { id: 8, name: "Snacks", category: "Grocery", price: 5, image: "https://oldfashioncandy.com/wp-content/uploads/2014/07/Mega-Variety-25-1-e1720019542149.jpeg", stars: 4 },
  { id: 9, name: "Dumbbell", category: "Fitness", price: 15, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQPd9rxSyLvQEvW8TqQ6T_5Z5xhyeKFoUnAw&s", stars: 5 },
  { id: 10, name: "Kitchen Accessories", category: "Home", price: 10, image: "https://www.allinonestore.pk/cdn/shop/files/12-pcs-silicone-cooking-utensils-set-933819.webp?v=1755460541", stars: 4 },
  { id: 11, name: "School Accessories Set", category: "Stationery", price: 15, image: "https://img.freepik.com/free-vector/school-student-stationary-supplies-shelf_3446-469.jpg", stars: 4 },
  { id: 12, name: "Bag", category: "Fashion", price: 50, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRtgRHUdIrtzyTBeNc54Q_W-6RvqY5r52KsVw&s", stars: 5 },
];

const productDesc = {
  1: "Luxury fragrances for every occasion. Long-lasting, bold, and unforgettable.",
  2: "Classic polo tee crafted from 100% breathable cotton. Perfect for casual outings.",
  3: "Elegant formal shirt with sharp stitching — office-ready and style-approved.",
  4: "High-performance sportswear built for movement, comfort, and sweat resistance.",
  5: "Premium sneakers with cushioned soles — all-day comfort meets street style.",
  6: "Fun, safe, and durable toys guaranteed to keep kids entertained for hours.",
  7: "Powerful tablet with crisp FHD display — work, stream, and create anywhere.",
  8: "A delightful assortment of sweet and salty treats for any occasion.",
  9: "Heavy-duty cast iron dumbbells for serious home and gym workouts.",
  10: "Complete silicone kitchen set — heat-resistant, non-stick, and easy to clean.",
  11: "Everything a student needs — stationery, organizers, and more in one kit.",
  12: "Stylish and spacious bag — great for travel, work, or everyday carry.",
};

const WHATSAPP_NUMBER = "923159833357";
let cart = JSON.parse(localStorage.getItem("qc_cart")) || [];
let currentCategory = "All";
const REDUCE_MOTION = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ============================================================
   THEME
   ============================================================ */
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme === "light" ? "light" : "dark");
}
function toggleTheme() {
  const current = document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  const next = current === "light" ? "dark" : "light";
  applyTheme(next);
  try { localStorage.setItem("qc_theme", next); } catch (e) {}
}

/* ============================================================
   LOADER
   ============================================================ */
function hideLoader() {
  const loader = document.getElementById("qc-loader");
  if (!loader || loader.dataset.hidden) return;
  loader.dataset.hidden = "1";
  loader.classList.add("qc-loader-hide");
  setTimeout(() => loader.remove(), 420);
}

/* ============================================================
   MOBILE NAV (shared across all pages)
   ============================================================ */
function openMobileNav() {
  const nav = document.getElementById("mobileNav");
  if (nav) nav.classList.add("open");
}
function closeMobileNav() {
  const nav = document.getElementById("mobileNav");
  if (nav) nav.classList.remove("open");
}

/* ============================================================
   TOAST ENGINE
   ============================================================ */
const toastMeta = {
  success: { icon: "✅", label: "Success" },
  error: { icon: "❌", label: "Error" },
  warning: { icon: "⚠️", label: "Notice" },
  info: { icon: "ℹ️", label: "Info" },
  cart: { icon: "🛒", label: "Cart" },
  order: { icon: "📦", label: "Order" },
};

function ensureToastStack() {
  let stack = document.getElementById("qc-toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.id = "qc-toast-stack";
    document.body.appendChild(stack);
  }
  return stack;
}

function showToast(message, type = "success", duration = 3000) {
  const stack = ensureToastStack();
  const m = toastMeta[type] || toastMeta.success;
  const toast = document.createElement("div");
  toast.className = "qc-toast " + type;
  toast.innerHTML =
    '<span class="qc-toast-icon">' + m.icon + '</span>' +
    '<div class="qc-toast-body"><div class="qc-toast-title">' + m.label + '</div>' +
    '<div class="qc-toast-msg">' + message + '</div></div>' +
    '<button class="qc-toast-close">✕</button>' +
    '<div class="qc-toast-progress" style="animation-duration:' + duration + 'ms"></div>';
  stack.appendChild(toast);
  toast.querySelector(".qc-toast-close").addEventListener("click", () => dismissToast(toast));
  requestAnimationFrame(() => requestAnimationFrame(() => toast.classList.add("show")));
  setTimeout(() => dismissToast(toast), duration);
}

function dismissToast(toast) {
  if (!toast || !toast.parentElement) return;
  toast.classList.replace("show", "hide");
  setTimeout(() => toast.remove(), 400);
}

/* ============================================================
   STACKED / NESTED MODAL ENGINE
   Every showXxx() opens a NEW layer on top of whatever is already
   open, so popups genuinely nest (e.g. a confirm on top of a
   quick-view) instead of replacing one another.
   ============================================================ */
let modalStack = [];

function ensureModalRoot() {
  let root = document.getElementById("qc-modal-root");
  if (!root) {
    root = document.createElement("div");
    root.id = "qc-modal-root";
    document.body.appendChild(root);
  }
  return root;
}

function openModalLayer(html, opts = {}) {
  const root = ensureModalRoot();
  const depth = modalStack.length;
  const backdrop = document.createElement("div");
  backdrop.className = "qc-modal-backdrop";
  backdrop.dataset.depth = String(Math.min(depth, 2));
  const box = document.createElement("div");
  box.className = "qc-modal" + (opts.extraClass ? " " + opts.extraClass : "");
  box.innerHTML = html;
  backdrop.appendChild(box);
  root.appendChild(backdrop);
  modalStack.push(backdrop);

  document.body.style.overflow = "hidden";
  requestAnimationFrame(() => requestAnimationFrame(() => backdrop.classList.add("show")));

  if (opts.dismissible !== false) {
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) closeTopModal(); });
  }
  return box;
}

function closeTopModal() {
  const backdrop = modalStack.pop();
  if (!backdrop) return;
  backdrop.classList.remove("show");
  backdrop.classList.add("closing");
  setTimeout(() => backdrop.remove(), 380);
  if (modalStack.length === 0) document.body.style.overflow = "";
}

/* back-compat aliases */
function showModal(html) { return openModalLayer(html); }
function closeModal() { closeTopModal(); }

/* ─── CONFIRM DIALOG ─────────────────────────────────────── */
function showConfirm(opts) {
  const { emoji = "❓", title, message, confirmText = "Yes", cancelText = "Cancel",
    confirmClass = "danger", onConfirm } = opts;
  const box = openModalLayer(
    '<span class="qc-modal-emoji">' + emoji + '</span>' +
    '<h3>' + title + '</h3><p>' + message + '</p>' +
    '<div class="qc-modal-btns">' +
    '<button class="qc-modal-btn secondary qc-btn-cancel">' + cancelText + '</button>' +
    '<button class="qc-modal-btn ' + confirmClass + ' qc-btn-confirm">' + confirmText + '</button>' +
    '</div>'
  );
  box.querySelector(".qc-btn-cancel").addEventListener("click", closeTopModal);
  box.querySelector(".qc-btn-confirm").addEventListener("click", () => {
    closeTopModal();
    if (typeof onConfirm === "function") onConfirm();
  });
}

/* ─── ALERT DIALOG ───────────────────────────────────────── */
function showAlert(opts) {
  const { emoji = "ℹ️", title, message, btnText = "Got it", btnClass = "primary", onOk } = opts;
  const box = openModalLayer(
    '<span class="qc-modal-emoji">' + emoji + '</span>' +
    '<h3>' + title + '</h3><p>' + message + '</p>' +
    '<div class="qc-modal-btns">' +
    '<button class="qc-modal-btn ' + btnClass + ' qc-btn-ok">' + btnText + '</button>' +
    '</div>'
  );
  box.querySelector(".qc-btn-ok").addEventListener("click", () => {
    closeTopModal();
    if (typeof onOk === "function") onOk();
  });
}

/* ─── QUICK-VIEW POPUP (supports a nested remove-confirm) ── */
function showQuickView(productId) {
  const p = products.find(x => x.id === productId);
  if (!p) return;
  const box = openModalLayer("", { extraClass: "qc-quickview" });
  renderQuickviewBody(box, p);
}

function renderQuickviewBody(box, p) {
  const inCart = cart.find(i => i.id === p.id);
  const actionBtn = inCart
    ? '<button class="qc-modal-btn danger qc-qv-remove">🗑 Remove from Cart</button>'
    : '<button class="qc-modal-btn primary qc-qv-add">+ Add to Cart</button>';

  box.innerHTML =
    '<img class="qc-quickview-img" src="' + p.image + '" ' +
    'onerror="this.src=\'https://via.placeholder.com/500x220/141414/555?text=No+Image\'" />' +
    '<div class="qc-quickview-body">' +
    '<span class="qc-quickview-cat">' + p.category + '</span>' +
    '<h3>' + p.name + '</h3>' +
    '<div class="qc-quickview-stars">' + getStars(p.stars) + ' &nbsp;<small style="opacity:.6;font-size:12px;">(' + p.stars + '.0)</small></div>' +
    '<div class="qc-quickview-price">$' + p.price + '</div>' +
    '<p class="qc-quickview-desc">' + (productDesc[p.id] || "Premium quality product from QuickCart.") + '</p>' +
    (inCart ? '<p style="font-size:12px;opacity:.6;margin-top:-12px;margin-bottom:16px;">Cart mein qty: ' + inCart.qty + '</p>' : '') +
    '<div class="qc-modal-btns" style="justify-content:flex-start;">' +
    actionBtn +
    '<button class="qc-modal-btn secondary qc-qv-close">Close</button>' +
    '</div></div>';

  const addBtn = box.querySelector(".qc-qv-add");
  if (addBtn) addBtn.addEventListener("click", () => { addToCart(p.id); renderQuickviewBody(box, p); });

  const removeBtn = box.querySelector(".qc-qv-remove");
  if (removeBtn) removeBtn.addEventListener("click", () => {
    /* nested confirm — stacks ON TOP of this still-open quick view */
    showConfirm({
      emoji: "🗑️",
      title: "Remove " + p.name + "?",
      message: "Ye product aapke cart se hatana chahte hain?",
      confirmText: "Haan, Remove Karo",
      cancelText: "Rehne Do",
      confirmClass: "danger",
      onConfirm: () => { removeFromCart(p.id); renderQuickviewBody(box, p); }
    });
  });

  const closeBtn = box.querySelector(".qc-qv-close");
  if (closeBtn) closeBtn.addEventListener("click", closeTopModal);
}

/* ─── ORDER SUCCESS POPUP ────────────────────────────────── */
function showOrderSuccess() {
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const rows = cart.map(i =>
    '<div class="qc-order-summary-row"><span>' + i.name + ' x' + i.qty + '</span><span>$' + i.price * i.qty + '</span></div>'
  ).join("");
  const box = openModalLayer(
    '<span class="qc-confetti">🎉</span>' +
    '<h3>Order Sent!</h3>' +
    '<p>WhatsApp par aapka order send ho gaya. Jald hi aap se rabta hoga! 🚀</p>' +
    '<div class="qc-order-summary">' + rows +
    '<div class="qc-order-summary-row"><span>Total</span><span>$' + total + '</span></div>' +
    '</div>' +
    '<div class="qc-modal-btns">' +
    '<button class="qc-modal-btn primary qc-btn-ok">🙌 Shukriya!</button>' +
    '</div>'
  );
  box.querySelector(".qc-btn-ok").addEventListener("click", closeTopModal);
}

/* ─── WELCOME POPUP (once per session) ──────────────────── */
function maybeShowWelcome() {
  if (sessionStorage.getItem("qc_welcomed")) return;
  sessionStorage.setItem("qc_welcomed", "1");
  setTimeout(() => {
    const box = openModalLayer(
      '<span class="qc-modal-emoji" style="font-size:52px;">⚡</span>' +
      '<span class="qc-welcome-badge">WELCOME</span>' +
      '<h3>QuickCart Premium mein Khush Amdeed!</h3>' +
      '<p>Pakistan ka #1 WhatsApp store. Premium products, best prices, aur lightning-fast delivery! 🛍️</p>' +
      '<div class="qc-modal-btns">' +
      '<button class="qc-modal-btn primary qc-btn-shop">Shop Now →</button>' +
      '<button class="qc-modal-btn secondary qc-btn-later">Browse Later</button>' +
      '</div>'
    );
    box.querySelector(".qc-btn-shop").addEventListener("click", () => { closeTopModal(); window.location.href = "product.html"; });
    box.querySelector(".qc-btn-later").addEventListener("click", closeTopModal);
  }, 900);
}

/* ─── RIPPLE EFFECT ──────────────────────────────────────── */
function addRipple(btn, e) {
  const r = btn.getBoundingClientRect();
  const size = Math.max(r.width, r.height);
  const x = e.clientX - r.left - size / 2;
  const y = e.clientY - r.top - size / 2;
  const rip = document.createElement("span");
  rip.className = "qc-ripple";
  rip.style.cssText = "width:" + size + "px;height:" + size + "px;left:" + x + "px;top:" + y + "px;";
  btn.style.position = "relative";
  btn.style.overflow = "hidden";
  btn.appendChild(rip);
  setTimeout(() => rip.remove(), 700);
}

/* ─── CART PERSISTENCE ───────────────────────────────────── */
function saveCart() {
  localStorage.setItem("qc_cart", JSON.stringify(cart));
}

/* ─── STARS ──────────────────────────────────────────────── */
function getStars(n) {
  return "★".repeat(n) + "☆".repeat(5 - n);
}

/* ============================================================
   CATEGORY FILTERING (products page)
   ============================================================ */
function getCategories() {
  const set = new Set(products.map(p => p.category));
  return ["All", ...Array.from(set)];
}

function renderCategoryPills() {
  const container = document.getElementById("categoryStrip");
  if (!container) return;
  const cats = getCategories();
  container.innerHTML = cats.map(c =>
    '<button class="cat-pill' + (c === currentCategory ? " active" : "") + '" data-cat="' + c + '">' + c + '</button>'
  ).join("");
  container.querySelectorAll(".cat-pill").forEach(btn => {
    btn.addEventListener("click", () => {
      currentCategory = btn.dataset.cat;
      container.querySelectorAll(".cat-pill").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      filterProducts();
    });
  });
}

function filterProducts() {
  const searchEl = document.getElementById("searchBox");
  const q = searchEl ? searchEl.value.toLowerCase() : "";
  let list = products;
  if (currentCategory !== "All") list = list.filter(p => p.category === currentCategory);
  if (q) list = list.filter(p => p.name.toLowerCase().includes(q));
  renderProducts("allProductsGrid", list);
  const noRes = document.getElementById("noResults");
  if (noRes) noRes.style.display = list.length === 0 ? "block" : "none";
}

/* ============================================================
   RENDER PRODUCTS (+ 3D tilt on hover)
   ============================================================ */
function renderProducts(containerId, list) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = "";
  if (list.length === 0) return;

  list.forEach((p, idx) => {
    const card = document.createElement("div");
    card.className = "product-card reveal";
    card.style.transitionDelay = (idx * 55) + "ms";
    card.innerHTML =
      '<div class="product-card-img-wrap" onclick="showQuickView(' + p.id + ')" style="cursor:pointer" title="Quick View">' +
      '<img src="' + p.image + '" alt="' + p.name + '" loading="lazy" ' +
      'onerror="this.src=\'https://via.placeholder.com/300x200/141414/555?text=No+Image\'" />' +
      '</div>' +
      '<div class="product-card-body">' +
      '<h3>' + p.name + '</h3>' +
      '<div class="product-meta">' +
      '<div class="price">$' + p.price + '</div>' +
      '<div class="product-stars">' + getStars(p.stars || 4) + '</div>' +
      '</div>' +
      '<button class="add-cart-btn" id="btn-' + p.id + '" onclick="handleAddToCart(' + p.id + ',event)">+ Add to Cart</button>' +
      '</div>';
    container.appendChild(card);

    if (!REDUCE_MOTION) {
      card.addEventListener("mousemove", (e) => {
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width;
        const y = (e.clientY - r.top) / r.height;
        const rotateX = (0.5 - y) * 9;
        const rotateY = (x - 0.5) * 11;
        card.style.transform = "perspective(900px) rotateX(" + rotateX.toFixed(2) + "deg) rotateY(" + rotateY.toFixed(2) + "deg) translateY(-6px)";
        card.style.setProperty("--mx", (x * 100).toFixed(1) + "%");
        card.style.setProperty("--my", (y * 100).toFixed(1) + "%");
      });
      card.addEventListener("mouseleave", () => { card.style.transform = ""; });
    }
  });

  observeCards();
}

/* ─── SCROLL REVEAL ──────────────────────────────────────── */
let _obs = null;
function observeCards() {
  if (_obs) _obs.disconnect();
  _obs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); });
  }, { threshold: 0.08 });
  document.querySelectorAll(".product-card.reveal").forEach(c => _obs.observe(c));
}

/* ─── ADD TO CART ────────────────────────────────────────── */
function handleAddToCart(productId, event) {
  if (event) addRipple(event.currentTarget, event);
  addToCart(productId);
}

function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  if (!product) return;

  const existing = cart.find(i => i.id === productId);
  if (existing) {
    existing.qty++;
    showToast(product.name + " — Qty: " + existing.qty, "cart", 2200);
  } else {
    cart.push({ ...product, qty: 1 });
    showToast(product.name + " cart mein add ho gaya!", "cart", 2500);
  }

  saveCart();
  updateCartUI();

  const totalItems = cart.reduce((s, i) => s + i.qty, 0);
  if (totalItems === 5) showToast("🔥 5 items! Aap toh shopping pro ho!", "info", 3200);
  if (totalItems === 10) showToast("🏆 10 items — Amazing shopper!", "info", 3200);

  const btn = document.getElementById("btn-" + productId);
  if (btn) {
    btn.textContent = "✓ Added!";
    btn.classList.add("added");
    setTimeout(() => { btn.textContent = "+ Add to Cart"; btn.classList.remove("added"); }, 1600);
  }
}

/* ─── REMOVE FROM CART ───────────────────────────────────── */
function removeFromCart(productId) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  const name = item.name;
  cart = cart.filter(i => i.id !== productId);
  saveCart();
  updateCartUI();
  renderCartItems();
  showToast(name + " remove ho gaya.", "warning", 2200);
}

/* ─── UPDATE QTY ─────────────────────────────────────────── */
function updateQty(productId, delta) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) { removeFromCart(productId); return; }
  saveCart();
  updateCartUI();
  renderCartItems();
}

/* ─── CLEAR CART (with confirm popup) ───────────────────── */
function clearCart() {
  if (cart.length === 0) { showToast("Cart pehle se khali hai!", "info", 2000); return; }
  showConfirm({
    emoji: "🗑️",
    title: "Cart Clear Karen?",
    message: "Aapke cart mein " + cart.length + " item(s) hain. Kya sach mein sab hatana chahte hain?",
    confirmText: "Haan, Clear Karo",
    cancelText: "Nahi",
    confirmClass: "danger",
    onConfirm: () => {
      cart = [];
      saveCart();
      updateCartUI();
      renderCartItems();
      showToast("Cart clear ho gaya!", "warning", 2500);
    }
  });
}

/* ─── RENDER CART ITEMS ──────────────────────────────────── */
function renderCartItems() {
  const body = document.getElementById("cartBody");
  const empty = document.getElementById("cartEmpty");
  const footer = document.getElementById("cartFooter");
  const totalEl = document.getElementById("cartTotal");
  if (!body) return;

  body.querySelectorAll(".cart-item").forEach(el => el.remove());

  if (cart.length === 0) {
    if (empty) empty.style.display = "block";
    if (footer) footer.style.display = "none";
    return;
  }

  if (empty) empty.style.display = "none";
  if (footer) footer.style.display = "flex";

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  if (totalEl) totalEl.textContent = "$" + total;

  cart.forEach(item => {
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML =
      '<img src="' + item.image + '" alt="' + item.name + '" ' +
      'onerror="this.src=\'https://via.placeholder.com/62/141414/555?text=?\'" />' +
      '<div class="cart-item-info">' +
      '<h4>' + item.name + '</h4>' +
      '<span class="item-price">$' + item.price * item.qty + '</span>' +
      '<div class="cart-item-controls">' +
      '<button class="qty-btn" onclick="updateQty(' + item.id + ',-1)">−</button>' +
      '<span class="qty-num">' + item.qty + '</span>' +
      '<button class="qty-btn" onclick="updateQty(' + item.id + ',1)">+</button>' +
      '</div>' +
      '</div>' +
      '<button class="remove-btn" onclick="removeFromCart(' + item.id + ')" title="Remove">✕</button>';
    body.appendChild(div);
  });
}

/* ─── CART BADGE ─────────────────────────────────────────── */
function updateCartUI() {
  const total = cart.reduce((s, i) => s + i.qty, 0);
  document.querySelectorAll("#cartBadge").forEach(el => {
    el.textContent = total;
    el.style.transform = "scale(1.45)";
    setTimeout(() => { el.style.transform = "scale(1)"; }, 260);
  });
  renderCartItems();
}

/* ─── TOGGLE CART SIDEBAR ────────────────────────────────── */
function toggleCart() {
  const sidebar = document.getElementById("cartSidebar");
  const overlay = document.getElementById("cartOverlay");
  if (!sidebar) return;
  const isOpen = sidebar.classList.contains("open");
  sidebar.classList.toggle("open", !isOpen);
  if (overlay) overlay.classList.toggle("show", !isOpen);
  if (!isOpen && cart.length === 0)
    setTimeout(() => showToast("Cart khali hai! Koi cheez add karo 🛍️", "info", 2500), 350);
}

/* ─── WHATSAPP ORDER ─────────────────────────────────────── */
function orderOnWhatsApp() {
  if (cart.length === 0) {
    showAlert({
      emoji: "🛒",
      title: "Cart Khali Hai!",
      message: "Order karne se pehle koi product add karo. Products page dekhein!",
      btnText: "Products Dekhein →",
      btnClass: "primary",
      onOk: () => { window.location.href = "product.html"; }
    });
    return;
  }

  showConfirm({
    emoji: "📲",
    title: "WhatsApp par Order Karen?",
    message: cart.length + " item(s) — WhatsApp khulega aur order details send honge!",
    confirmText: "✅ Haan, Order Karo!",
    cancelText: "Ruko",
    confirmClass: "primary",
    onConfirm: () => {
      const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
      let msg = "🛒 *QuickCart — Naya Order!*\n━━━━━━━━━━━━━━━━━\n\n";
      cart.forEach((item, i) => {
        msg += (i + 1) + ". *" + item.name + "*\n   Qty: " + item.qty + " × $" + item.price + " = *$" + item.price * item.qty + "*\n\n";
      });
      msg += "━━━━━━━━━━━━━━━━━\n💰 *Total: $" + total + "*\n\n📍 Please apna address bhi batain.\nShukriya! 🙏";
      window.open("https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(msg), "_blank");
      setTimeout(() => showOrderSuccess(), 400);
    }
  });
}

/* ─── KEYBOARD ───────────────────────────────────────────── */
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (modalStack.length > 0) { closeTopModal(); return; }
  const sidebar = document.getElementById("cartSidebar");
  const overlay = document.getElementById("cartOverlay");
  if (sidebar && sidebar.classList.contains("open")) {
    sidebar.classList.remove("open");
    if (overlay) overlay.classList.remove("show");
  }
});

/* ─── INIT ───────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("#cartBadge").forEach(el => {
    el.style.transition = "transform .26s cubic-bezier(.34,1.56,.64,1)";
  });
  maybeShowWelcome();
});
