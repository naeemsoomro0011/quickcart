/* ============================================================
   QuickCart Premium — Professional JS Engine v2.0
   ✦ Stylish Popups  ✦ Smooth Animations  ✦ Rich Alerts
   ============================================================ */

const products = [
  { id: 1,  name: "Perfumes",              price: 25,  image: "https://i.pinimg.com/736x/9c/b2/5b/9cb25b1f0ed06b93ddf9689dd39ca0cf.jpg", stars: 5 },
  { id: 2,  name: "Polo T-Shirt",          price: 30,  image: "https://tse3.mm.bing.net/th/id/OIP.RLGEOTBNCsd7_HUxGzPjjQHaIr?rs=1&pid=ImgDetMain&o=7&rm=3", stars: 4 },
  { id: 3,  name: "Formal Shirt",          price: 20,  image: "https://tse3.mm.bing.net/th/id/OIP.uGYkmMlMKarOtbOvRQko_wHaE4?rs=1&pid=ImgDetMain&o=7&rm=3", stars: 5 },
  { id: 4,  name: "Sports Wear",           price: 25,  image: "https://th.bing.com/th/id/OIP.h-rpfiQiN9vLrJzKEfwBHwHaE7?w=298&h=199&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3", stars: 4 },
  { id: 5,  name: "Sneakers",              price: 15,  image: "https://onedegree.com.pk/cdn/shop/files/001_0003_009593984-749-42_up_jpg_1.jpg?v=1773400763&width=640", stars: 5 },
  { id: 6,  name: "Toys",                  price: 5,   image: "https://www.telegraph.co.uk/content/dam/recommended/2024/09/25/TELEMMGLPICT000395471929_17272789739160_trans_NvBQzQNjv4BqqVzuuqpFlyLIwiB6NTmJwfSVWeZ_vEN7c6bHu2jJnT8.jpeg?imwidth=640", stars: 4 },
  { id: 7,  name: "Tablets",               price: 200, image: "https://i5.walmartimages.com/seo/Lenovo-Tab-M10-Plus-2022-10-FHD-Long-Battery-Life-Tablet-128GB-Android-Storm-Grey_6d20d86e-e339-4dea-a97d-788dbf71f08c.50da7e377a5410315db7b2430fc13a86.png", stars: 5 },
  { id: 8,  name: "Snacks",                price: 5,   image: "https://oldfashioncandy.com/wp-content/uploads/2014/07/Mega-Variety-25-1-e1720019542149.jpeg", stars: 4 },
  { id: 9,  name: "Dumbbell",              price: 15,  image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQPd9rxSyLvQEvW8TqQ6T_5Z5xhyeKFoUnAw&s", stars: 5 },
  { id: 10, name: "Kitchen Accessories",   price: 10,  image: "https://www.allinonestore.pk/cdn/shop/files/12-pcs-silicone-cooking-utensils-set-933819.webp?v=1755460541", stars: 4 },
  { id: 11, name: "School Accessories Set",price: 15,  image: "https://img.freepik.com/free-vector/school-student-stationary-supplies-shelf_3446-469.jpg", stars: 4 },
  { id: 12, name: "Bag",                   price: 50,  image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRtgRHUdIrtzyTBeNc54Q_W-6RvqY5r52KsVw&s", stars: 5 },
];

const WHATSAPP_NUMBER = "923213118485";
let cart = JSON.parse(localStorage.getItem("qc_cart")) || [];

/* ─── INJECT POPUP STYLES (once) ─────────────────────────── */
(function injectPopupStyles() {
  if (document.getElementById("qc-popup-styles")) return;
  const style = document.createElement("style");
  style.id = "qc-popup-styles";
  style.textContent = `
    #qc-toast-stack {
      position:fixed;bottom:28px;right:24px;display:flex;flex-direction:column-reverse;
      gap:10px;z-index:99999;pointer-events:none;
    }
    .qc-toast {
      display:flex;align-items:center;gap:12px;
      background:#1a1a1a;border:1px solid rgba(255,255,255,.1);
      color:#f0f0f0;border-radius:14px;padding:14px 20px;
      min-width:280px;max-width:360px;
      font-family:'DM Sans',sans-serif;font-size:14px;
      box-shadow:0 8px 32px rgba(0,0,0,.5);
      pointer-events:all;cursor:default;position:relative;overflow:hidden;
      transform:translateX(120%);opacity:0;
      transition:transform .38s cubic-bezier(.34,1.56,.64,1),opacity .3s ease;
    }
    .qc-toast.show{transform:translateX(0);opacity:1;}
    .qc-toast.hide{transform:translateX(120%);opacity:0;}
    .qc-toast-icon{font-size:20px;flex-shrink:0;}
    .qc-toast-body{flex:1;}
    .qc-toast-title{font-weight:600;margin-bottom:1px;}
    .qc-toast-msg{font-size:12px;opacity:.75;}
    .qc-toast-close{font-size:16px;opacity:.5;cursor:pointer;background:none;border:none;color:inherit;padding:0;line-height:1;}
    .qc-toast-close:hover{opacity:1;}
    .qc-toast-progress{position:absolute;bottom:0;left:0;height:3px;border-radius:0 0 14px 14px;width:100%;transform-origin:left;animation:qc-shrink linear forwards;}
    @keyframes qc-shrink{from{transform:scaleX(1);}to{transform:scaleX(0);}}
    .qc-toast.success .qc-toast-progress{background:linear-gradient(90deg,#25D366,#128C7E);}
    .qc-toast.error   .qc-toast-progress{background:linear-gradient(90deg,#ff4d4d,#c0392b);}
    .qc-toast.warning .qc-toast-progress{background:linear-gradient(90deg,#f39c12,#e67e22);}
    .qc-toast.info    .qc-toast-progress{background:linear-gradient(90deg,#3498db,#2980b9);}
    .qc-toast.cart    .qc-toast-progress{background:linear-gradient(90deg,#a29bfe,#6c5ce7);}

    #qc-modal-backdrop {
      position:fixed;inset:0;z-index:99998;
      background:rgba(0,0,0,.75);backdrop-filter:blur(6px);
      display:flex;align-items:center;justify-content:center;
      opacity:0;pointer-events:none;transition:opacity .3s ease;
    }
    #qc-modal-backdrop.show{opacity:1;pointer-events:all;}
    .qc-modal {
      background:#111;border:1px solid rgba(255,255,255,.12);
      border-radius:22px;padding:36px 32px 28px;
      min-width:320px;max-width:420px;width:90%;
      box-shadow:0 24px 80px rgba(0,0,0,.7);
      text-align:center;font-family:'DM Sans',sans-serif;color:#f0f0f0;
      transform:scale(.88) translateY(20px);opacity:0;
      transition:transform .4s cubic-bezier(.34,1.56,.64,1),opacity .3s ease;
      position:relative;
    }
    #qc-modal-backdrop.show .qc-modal{transform:scale(1) translateY(0);opacity:1;}
    .qc-modal-emoji{font-size:48px;margin-bottom:14px;display:block;animation:qc-bounce .6s ease;}
    @keyframes qc-bounce{0%,100%{transform:translateY(0);}50%{transform:translateY(-10px);}}
    .qc-modal h3{font-family:'Syne',sans-serif;font-size:20px;font-weight:700;margin:0 0 10px;}
    .qc-modal p{font-size:14px;opacity:.75;line-height:1.6;margin:0 0 22px;}
    .qc-modal-btns{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;}
    .qc-modal-btn{
      padding:11px 24px;border-radius:50px;font-size:14px;font-weight:600;
      cursor:pointer;border:none;transition:all .2s ease;font-family:'DM Sans',sans-serif;
    }
    .qc-modal-btn.primary{background:linear-gradient(135deg,#25D366,#128C7E);color:#fff;box-shadow:0 4px 18px rgba(37,211,102,.3);}
    .qc-modal-btn.primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(37,211,102,.4);}
    .qc-modal-btn.secondary{background:rgba(255,255,255,.08);color:#ccc;border:1px solid rgba(255,255,255,.15);}
    .qc-modal-btn.secondary:hover{background:rgba(255,255,255,.15);color:#fff;}
    .qc-modal-btn.danger{background:linear-gradient(135deg,#ff4d4d,#c0392b);color:#fff;box-shadow:0 4px 18px rgba(255,77,77,.3);}
    .qc-modal-btn.danger:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(255,77,77,.45);}

    .qc-quickview{max-width:500px;text-align:left;padding:0;overflow:hidden;}
    .qc-quickview-img{width:100%;height:220px;object-fit:cover;border-radius:22px 22px 0 0;display:block;}
    .qc-quickview-body{padding:24px 28px 28px;}
    .qc-quickview-body h3{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;margin:0 0 6px;}
    .qc-quickview-stars{color:#f5c518;font-size:16px;margin-bottom:10px;}
    .qc-quickview-price{font-size:26px;font-weight:700;color:#25D366;margin-bottom:16px;}
    .qc-quickview-desc{font-size:13px;opacity:.65;line-height:1.7;margin-bottom:22px;}

    .qc-order-summary{background:rgba(255,255,255,.06);border-radius:12px;padding:14px 18px;margin:0 0 20px;text-align:left;}
    .qc-order-summary-row{display:flex;justify-content:space-between;font-size:13px;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.06);}
    .qc-order-summary-row:last-child{border:none;font-weight:700;color:#25D366;font-size:15px;}
    .qc-confetti{font-size:60px;display:block;margin-bottom:14px;animation:qc-spin .8s ease;}
    @keyframes qc-spin{from{transform:rotate(-20deg) scale(.5);}to{transform:rotate(0) scale(1);}}

    .qc-welcome-badge{
      display:inline-block;background:linear-gradient(135deg,#25D366,#128C7E);
      color:#fff;border-radius:50px;font-size:11px;font-weight:700;
      padding:4px 14px;letter-spacing:1px;margin-bottom:14px;
    }

    .product-card{opacity:0;transform:translateY(24px);transition:opacity .45s ease,transform .45s ease;}
    .product-card.visible{opacity:1;transform:translateY(0);}

    .qc-ripple{
      position:absolute;border-radius:50%;
      background:rgba(255,255,255,.25);pointer-events:none;
      transform:scale(0);animation:qc-ripple-anim .6s linear forwards;
    }
    @keyframes qc-ripple-anim{to{transform:scale(4);opacity:0;}}

    @keyframes qc-slideIn{from{opacity:0;transform:translateX(-16px);}to{opacity:1;transform:translateX(0);}}
  `;
  document.head.appendChild(style);

  const stack = document.createElement("div");
  stack.id = "qc-toast-stack";
  document.body.appendChild(stack);

  const backdrop = document.createElement("div");
  backdrop.id = "qc-modal-backdrop";
  backdrop.innerHTML = '<div class="qc-modal" id="qc-modal-box"></div>';
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) closeModal(); });
  document.body.appendChild(backdrop);
})();

/* ─── TOAST ENGINE ────────────────────────────────────────── */
const toastMeta = {
  success:{ icon:"✅", label:"Success" },
  error:  { icon:"❌", label:"Error"   },
  warning:{ icon:"⚠️",  label:"Notice"  },
  info:   { icon:"ℹ️",  label:"Info"   },
  cart:   { icon:"🛒", label:"Cart"   },
  order:  { icon:"📦", label:"Order"  },
};

function showToast(message, type="success", duration=3000) {
  const stack = document.getElementById("qc-toast-stack");
  const m = toastMeta[type] || toastMeta.success;
  const toast = document.createElement("div");
  toast.className = "qc-toast " + type;
  toast.innerHTML =
    '<span class="qc-toast-icon">'+m.icon+'</span>' +
    '<div class="qc-toast-body"><div class="qc-toast-title">'+m.label+'</div>' +
    '<div class="qc-toast-msg">'+message+'</div></div>' +
    '<button class="qc-toast-close" onclick="dismissToast(this.parentElement)">✕</button>' +
    '<div class="qc-toast-progress" style="animation-duration:'+duration+'ms"></div>';
  stack.appendChild(toast);
  requestAnimationFrame(() => requestAnimationFrame(() => toast.classList.add("show")));
  setTimeout(() => dismissToast(toast), duration);
}

function dismissToast(toast) {
  if (!toast || !toast.parentElement) return;
  toast.classList.replace("show","hide");
  setTimeout(() => toast.remove(), 400);
}

/* hide legacy toast if present */
const _lt = document.getElementById("toast");
if (_lt) _lt.style.display = "none";

/* ─── MODAL ENGINE ────────────────────────────────────────── */
function showModal(html) {
  const backdrop = document.getElementById("qc-modal-backdrop");
  const box = document.getElementById("qc-modal-box");
  box.className = "qc-modal";
  box.innerHTML = html;
  backdrop.classList.add("show");
  document.body.style.overflow = "hidden";
}

function closeModal() {
  document.getElementById("qc-modal-backdrop").classList.remove("show");
  document.body.style.overflow = "";
}

/* ─── CONFIRM DIALOG ─────────────────────────────────────── */
function showConfirm(opts) {
  const { emoji="❓", title, message, confirmText="Yes", cancelText="Cancel",
          confirmClass="danger", onConfirm } = opts;
  showModal(
    '<span class="qc-modal-emoji">'+emoji+'</span>' +
    '<h3>'+title+'</h3><p>'+message+'</p>' +
    '<div class="qc-modal-btns">' +
      '<button class="qc-modal-btn secondary" onclick="closeModal()">'+cancelText+'</button>' +
      '<button class="qc-modal-btn '+confirmClass+'" id="qc-confirm-ok">'+confirmText+'</button>' +
    '</div>'
  );
  document.getElementById("qc-confirm-ok").addEventListener("click", () => {
    closeModal();
    if (typeof onConfirm === "function") onConfirm();
  });
}

/* ─── ALERT DIALOG ───────────────────────────────────────── */
function showAlert(opts) {
  const { emoji="ℹ️", title, message, btnText="Got it", btnClass="primary" } = opts;
  showModal(
    '<span class="qc-modal-emoji">'+emoji+'</span>' +
    '<h3>'+title+'</h3><p>'+message+'</p>' +
    '<div class="qc-modal-btns">' +
      '<button class="qc-modal-btn '+btnClass+'" id="qc-alert-ok">'+btnText+'</button>' +
    '</div>'
  );
}

/* ─── QUICK-VIEW POPUP ───────────────────────────────────── */
const productDesc = {
  1:"Luxury fragrances for every occasion. Long-lasting, bold, and unforgettable.",
  2:"Classic polo tee crafted from 100% breathable cotton. Perfect for casual outings.",
  3:"Elegant formal shirt with sharp stitching — office-ready and style-approved.",
  4:"High-performance sportswear built for movement, comfort, and sweat resistance.",
  5:"Premium sneakers with cushioned soles — all-day comfort meets street style.",
  6:"Fun, safe, and durable toys guaranteed to keep kids entertained for hours.",
  7:"Powerful tablet with crisp FHD display — work, stream, and create anywhere.",
  8:"A delightful assortment of sweet and salty treats for any occasion.",
  9:"Heavy-duty cast iron dumbbells for serious home and gym workouts.",
  10:"Complete silicone kitchen set — heat-resistant, non-stick, and easy to clean.",
  11:"Everything a student needs — stationery, organizers, and more in one kit.",
  12:"Stylish and spacious bag — great for travel, work, or everyday carry.",
};

function showQuickView(productId) {
  const p = products.find(x => x.id === productId);
  if (!p) return;
  const inCart = cart.find(i => i.id === productId);
  const btnLabel = inCart ? "✓ In Cart ("+inCart.qty+")" : "+ Add to Cart";
  const box = document.getElementById("qc-modal-box");
  box.className = "qc-modal qc-quickview";
  box.innerHTML =
    '<img class="qc-quickview-img" src="'+p.image+'" ' +
    'onerror="this.src=\'https://via.placeholder.com/500x220/141414/555?text=No+Image\'" />' +
    '<div class="qc-quickview-body">' +
      '<h3>'+p.name+'</h3>' +
      '<div class="qc-quickview-stars">'+getStars(p.stars)+' &nbsp;<small style="opacity:.6;font-size:12px;">('+p.stars+'.0)</small></div>' +
      '<div class="qc-quickview-price">$'+p.price+'</div>' +
      '<p class="qc-quickview-desc">'+(productDesc[p.id]||"Premium quality product from QuickCart.")+'</p>' +
      '<div class="qc-modal-btns" style="justify-content:flex-start;">' +
        '<button class="qc-modal-btn primary" onclick="addToCart('+p.id+');closeModal();">'+btnLabel+'</button>' +
        '<button class="qc-modal-btn secondary" onclick="closeModal()">Close</button>' +
      '</div>' +
    '</div>';
  document.getElementById("qc-modal-backdrop").classList.add("show");
  document.body.style.overflow = "hidden";
}

/* ─── ORDER SUCCESS POPUP ────────────────────────────────── */
function showOrderSuccess() {
  const total = cart.reduce((s,i) => s + i.price*i.qty, 0);
  const rows = cart.map(i =>
    '<div class="qc-order-summary-row"><span>'+i.name+' x'+i.qty+'</span><span>$'+i.price*i.qty+'</span></div>'
  ).join("");
  showModal(
    '<span class="qc-confetti">🎉</span>' +
    '<h3>Order Sent!</h3>' +
    '<p>WhatsApp par aapka order send ho gaya. Jald hi aap se rabta hoga! 🚀</p>' +
    '<div class="qc-order-summary">'+rows+
      '<div class="qc-order-summary-row"><span>Total</span><span>$'+total+'</span></div>' +
    '</div>' +
    '<div class="qc-modal-btns">' +
      '<button class="qc-modal-btn primary" onclick="closeModal()">🙌 Shukriya!</button>' +
    '</div>'
  );
}

/* ─── WELCOME POPUP (once per session) ──────────────────── */
function maybeShowWelcome() {
  if (sessionStorage.getItem("qc_welcomed")) return;
  sessionStorage.setItem("qc_welcomed","1");
  setTimeout(() => {
    showModal(
      '<span class="qc-modal-emoji" style="font-size:52px;">⚡</span>' +
      '<span class="qc-welcome-badge">WELCOME</span>' +
      '<h3>QuickCart Premium mein Khush Amdeed!</h3>' +
      '<p>Pakistan ka #1 WhatsApp store. Premium products, best prices, aur lightning-fast delivery! 🛍️</p>' +
      '<div class="qc-modal-btns">' +
        '<button class="qc-modal-btn primary" onclick="closeModal();window.location.href=\'product.html\'">Shop Now →</button>' +
        '<button class="qc-modal-btn secondary" onclick="closeModal()">Browse Later</button>' +
      '</div>'
    );
  }, 1200);
}

/* ─── RIPPLE EFFECT ──────────────────────────────────────── */
function addRipple(btn, e) {
  const r = btn.getBoundingClientRect();
  const size = Math.max(r.width, r.height);
  const x = e.clientX - r.left - size/2;
  const y = e.clientY - r.top  - size/2;
  const rip = document.createElement("span");
  rip.className = "qc-ripple";
  rip.style.cssText = "width:"+size+"px;height:"+size+"px;left:"+x+"px;top:"+y+"px;";
  btn.style.position = "relative";
  btn.style.overflow = "hidden";
  btn.appendChild(rip);
  setTimeout(() => rip.remove(), 700);
}

/* ─── CART PERSISTENCE ───────────────────────────────────── */
function saveCart() {
  localStorage.setItem("qc_cart", JSON.stringify(cart));
}

/* ─── STARS ──────────────────────────────────────────────── */
function getStars(n) {
  return "★".repeat(n) + "☆".repeat(5 - n);
}

/* ─── RENDER PRODUCTS ────────────────────────────────────── */
function renderProducts(containerId, list) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = "";
  if (list.length === 0) return;

  list.forEach((p, idx) => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.style.transitionDelay = (idx * 60) + "ms";
    card.innerHTML =
      '<div class="product-card-img-wrap" onclick="showQuickView('+p.id+')" style="cursor:pointer" title="Quick View">' +
        '<img src="'+p.image+'" alt="'+p.name+'" loading="lazy" ' +
        'onerror="this.src=\'https://via.placeholder.com/300x200/141414/555?text=No+Image\'" />' +
      '</div>' +
      '<div class="product-card-body">' +
        '<h3>'+p.name+'</h3>' +
        '<div class="product-meta">' +
          '<div class="price">$'+p.price+'</div>' +
          '<div class="product-stars">'+getStars(p.stars||4)+'</div>' +
        '</div>' +
        '<button class="add-cart-btn" id="btn-'+p.id+'" onclick="handleAddToCart('+p.id+',event)">+ Add to Cart</button>' +
      '</div>';
    container.appendChild(card);
  });

  observeCards();
}

/* ─── SCROLL REVEAL ──────────────────────────────────────── */
let _obs = null;
function observeCards() {
  if (_obs) _obs.disconnect();
  _obs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); });
  }, { threshold: 0.1 });
  document.querySelectorAll(".product-card").forEach(c => _obs.observe(c));
}

/* ─── ADD TO CART ────────────────────────────────────────── */
function handleAddToCart(productId, event) {
  if (event) addRipple(event.currentTarget, event);
  addToCart(productId);
}

function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  if (!product) return;

  const existing = cart.find(i => i.id === productId);
  if (existing) {
    existing.qty++;
    showToast(product.name + " — Qty: " + existing.qty, "cart", 2200);
  } else {
    cart.push({ ...product, qty: 1 });
    showToast(product.name + " cart mein add ho gaya!", "cart", 2500);
  }

  saveCart();
  updateCartUI();

  const totalItems = cart.reduce((s,i) => s + i.qty, 0);
  if (totalItems === 5)  showToast("🔥 5 items! Aap toh shopping pro ho!", "info", 3200);
  if (totalItems === 10) showToast("🏆 10 items — Amazing shopper!", "info", 3200);

  const btn = document.getElementById("btn-" + productId);
  if (btn) {
    btn.textContent = "✓ Added!";
    btn.classList.add("added");
    setTimeout(() => { btn.textContent = "+ Add to Cart"; btn.classList.remove("added"); }, 1600);
  }
}

/* ─── REMOVE FROM CART ───────────────────────────────────── */
function removeFromCart(productId) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  const name = item.name;
  cart = cart.filter(i => i.id !== productId);
  saveCart();
  updateCartUI();
  renderCartItems();
  showToast(name + " remove ho gaya.", "warning", 2200);
}

/* ─── UPDATE QTY ─────────────────────────────────────────── */
function updateQty(productId, delta) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) { removeFromCart(productId); return; }
  saveCart();
  updateCartUI();
  renderCartItems();
}

/* ─── CLEAR CART (with confirm popup) ───────────────────── */
function clearCart() {
  if (cart.length === 0) { showToast("Cart pehle se khali hai!", "info", 2000); return; }
  showConfirm({
    emoji: "🗑️",
    title: "Cart Clear Karen?",
    message: "Aapke cart mein " + cart.length + " item(s) hain. Kya sach mein sab hatana chahte hain?",
    confirmText: "Haan, Clear Karo",
    cancelText: "Nahi",
    confirmClass: "danger",
    onConfirm: () => {
      cart = [];
      saveCart();
      updateCartUI();
      renderCartItems();
      showToast("Cart clear ho gaya!", "warning", 2500);
    }
  });
}

/* ─── RENDER CART ITEMS ──────────────────────────────────── */
function renderCartItems() {
  const body    = document.getElementById("cartBody");
  const empty   = document.getElementById("cartEmpty");
  const footer  = document.getElementById("cartFooter");
  const totalEl = document.getElementById("cartTotal");
  if (!body) return;

  body.querySelectorAll(".cart-item").forEach(el => el.remove());

  if (cart.length === 0) {
    if (empty)  empty.style.display  = "block";
    if (footer) footer.style.display = "none";
    return;
  }

  if (empty)  empty.style.display  = "none";
  if (footer) footer.style.display = "flex";

  const total = cart.reduce((s,i) => s + i.price*i.qty, 0);
  if (totalEl) totalEl.textContent = "$" + total;

  cart.forEach(item => {
    const div = document.createElement("div");
    div.className = "cart-item";
    div.style.animation = "qc-slideIn .3s ease";
    div.innerHTML =
      '<img src="'+item.image+'" alt="'+item.name+'" ' +
      'onerror="this.src=\'https://via.placeholder.com/62/141414/555?text=?\'" />' +
      '<div class="cart-item-info">' +
        '<h4>'+item.name+'</h4>' +
        '<span class="item-price">$'+item.price*item.qty+'</span>' +
        '<div class="cart-item-controls">' +
          '<button class="qty-btn" onclick="updateQty('+item.id+',-1)">−</button>' +
          '<span class="qty-num">'+item.qty+'</span>' +
          '<button class="qty-btn" onclick="updateQty('+item.id+',1)">+</button>' +
        '</div>' +
      '</div>' +
      '<button class="remove-btn" onclick="removeFromCart('+item.id+')" title="Remove">✕</button>';
    body.appendChild(div);
  });
}

/* ─── CART BADGE ─────────────────────────────────────────── */
function updateCartUI() {
  const total = cart.reduce((s,i) => s + i.qty, 0);
  document.querySelectorAll("#cartBadge").forEach(el => {
    el.textContent = total;
    el.style.transform = "scale(1.45)";
    setTimeout(() => { el.style.transform = "scale(1)"; }, 260);
  });
  renderCartItems();
}

/* ─── TOGGLE CART SIDEBAR ────────────────────────────────── */
function toggleCart() {
  const sidebar = document.getElementById("cartSidebar");
  const overlay = document.getElementById("cartOverlay");
  if (!sidebar) return;
  const isOpen = sidebar.classList.contains("open");
  sidebar.classList.toggle("open", !isOpen);
  if (overlay) overlay.classList.toggle("show", !isOpen);
  if (!isOpen && cart.length === 0)
    setTimeout(() => showToast("Cart khali hai! Koi cheez add karo 🛍️","info",2500), 350);
}

/* ─── WHATSAPP ORDER ─────────────────────────────────────── */
function orderOnWhatsApp() {
  if (cart.length === 0) {
    showAlert({
      emoji: "🛒",
      title: "Cart Khali Hai!",
      message: "Order karne se pehle koi product add karo. Products page dekhein!",
      btnText: "Products Dekhein →",
      btnClass: "primary",
    });
    setTimeout(() => {
      const btn = document.getElementById("qc-alert-ok");
      if (btn) btn.addEventListener("click", () => { closeModal(); window.location.href = "product.html"; });
    }, 50);
    return;
  }

  showConfirm({
    emoji: "📲",
    title: "WhatsApp par Order Karen?",
    message: cart.length + " item(s) — WhatsApp khulega aur order details send honge!",
    confirmText: "✅ Haan, Order Karo!",
    cancelText: "Ruko",
    confirmClass: "primary",
    onConfirm: () => {
      const total = cart.reduce((s,i) => s + i.price*i.qty, 0);
      let msg = "🛒 *QuickCart — Naya Order!*\n━━━━━━━━━━━━━━━━━\n\n";
      cart.forEach((item,i) => {
        msg += (i+1)+". *"+item.name+"*\n   Qty: "+item.qty+" × $"+item.price+" = *$"+item.price*item.qty+"*\n\n";
      });
      msg += "━━━━━━━━━━━━━━━━━\n💰 *Total: $"+total+"*\n\n📍 Please apna address bhi batain.\nShukriya! 🙏";
      window.open("https://wa.me/"+WHATSAPP_NUMBER+"?text="+encodeURIComponent(msg),"_blank");
      setTimeout(() => showOrderSuccess(), 400);
    }
  });
}

/* ─── KEYBOARD ───────────────────────────────────────────── */
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  const backdrop = document.getElementById("qc-modal-backdrop");
  const sidebar  = document.getElementById("cartSidebar");
  const overlay  = document.getElementById("cartOverlay");
  if (backdrop && backdrop.classList.contains("show")) { closeModal(); return; }
  if (sidebar  && sidebar.classList.contains("open")) {
    sidebar.classList.remove("open");
    if (overlay) overlay.classList.remove("show");
  }
});

/* ─── INIT ───────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("#cartBadge").forEach(el => {
    el.style.transition = "transform .26s cubic-bezier(.34,1.56,.64,1)";
  });
  updateCartUI();
  maybeShowWelcome();
});
